import './App.css';
import Slider from './Components/Slider';

function App() {
  return (
    <div className="App">
      <Slider/>
    </div>
  );
}

export default App;
